# FFTM paper performance data

This archive is a compact, data-only snapshot of the numerical inputs used for
the FFTM performance figures. Paths below `repo-data/` intentionally match the
paths expected by the tracked analysis scripts. The archive excludes generated
figures, raw cluster logs, container images, and turbulence field snapshots.

From an FFTM checkout, extract the archive anywhere and run:

```bash
DATA_ROOT=/path/to/fftm_paper_performance_data_20260808/repo-data
OUT=/tmp/fftm-paper-figures

python3 scripts/plot_final_performance_suite.py \
  --repo-root "$DATA_ROOT" \
  --output-dir "$OUT/final" \
  --dpi 600

python3 scripts/analyze_fftw_mpi_cpu_comparison.py \
  --cpu-data-dir "$DATA_ROOT/build/resutls_stats/data_fftw_mpi_cpu_prod_1n2n_20260728_090353" \
  --cpu-data-dir "$DATA_ROOT/build/resutls_stats/data_fftw_mpi_cpu_prod_4n_20260728_113419" \
  --gpu-selected-csv "$DATA_ROOT/build/resutls_stats/data_scale_hca_96_120_fixed_20260725_163251/analysis/hca_scaling_selected.csv" \
  --output-dir "$OUT/cpu-vs-gpu"

python3 scripts/analyze_hip_fftw_comparison.py \
  "$DATA_ROOT/build/resutls_stats/data_hip_fftw_minimal_20260803_150054" \
  --output-dir "$OUT/hip-vs-fftw"
```

The final suite writes six PDF/PNG figure sets for fitted 3D performance,
strong 3D and 4D scaling, weak 3D and 4D scaling, and same-system external
comparisons. `MANIFEST.sha256` covers every file in this archive except itself.
